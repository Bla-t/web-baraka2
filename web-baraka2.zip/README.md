# bootstrap-transparent-navbar
Bootstrap 5 - Responsive Transparent Navbar,  Fixed Top on Scroll Web Page

[Demo](https://skcals.github.io/bootstrap-transparent-navbar/)
