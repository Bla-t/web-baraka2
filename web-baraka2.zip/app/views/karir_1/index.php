<div class="banner-image w-100 vh-100 d-flex justify-content-center align-items-center">
  <div class="content text-center">
    <h1 class="text-dark">Lowongan Pekerjaan</h1>
  </div>
</div>
<div class="container my-5 d-grid gap-5">
  <div class="row">
    <div class="col" style="background-color: #FFCD91;">
      <img src="<?= BASEURL; ?>/img/logs.png" alt="low1" class="img d-flex justify-content-center">
      <div class="d-flex justify-content-center mb-2">
        <h1>LOWONGAN 1</h1>
      </div>
    </div>
  </div>
  <div class="row">
    <p>
      <strong>Lorem ipsum dolor sit</strong>,<br> amet consectetur adipisicing elit. Accusantium inventore fuga ea animi. Corporis voluptatem totam beatae eum recusandae perferendis quam, illum labore, quo sint odio quidem ipsa? Qui, nostrum?,<br><br>
      <strong>Lorem ipsum dolor sit</strong>,<br> amet consectetur adipisicing elit. Accusantium inventore fuga ea animi. Corporis voluptatem totam beatae eum recusandae perferendis quam, illum labore, quo sint odio quidem ipsa? Qui, nostrum?,<br><br>
      <strong>Lorem ipsum dolor sit</strong>,<br> amet consectetur adipisicing elit. Accusantium inventore fuga ea animi. Corporis voluptatem totam beatae eum recusandae perferendis quam, illum labore, quo sint odio quidem ipsa? Qui, nostrum?,<br><br>
      <strong>Lorem ipsum dolor sit</strong>,<br> amet consectetur adipisicing elit. Accusantium inventore fuga ea animi. Corporis voluptatem totam beatae eum recusandae perferendis quam, illum labore, quo sint odio quidem ipsa? Qui, nostrum?,<br><br>
    </p>
  </div>
</div>