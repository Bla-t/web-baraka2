<!-- Banner Image  -->
<style>
  .banner-image {
    background-image: url('<?= BASEURL; ?>/app/img/background3.jpeg');
    background-size: cover;
    /*filter: blur(8px);
      -webkit-filter: blur(8px);*/
  }

  h1 {
    text-shadow: 2px 2px 4px #000000;
  }
</style>
<div class="banner-image w-100 vh-100 d-flex justify-content-center align-items-center">
  <div class="content text-center">
    <h1>CEK HARGA PENGIRIMAN</h1>
    <h1>DARI KE TUJUAN</h1>
  </div>
</div>

<!-- Main Content Area -->
<div class="container my-5 d-grid gap-5">
  <div class="ratio ratio-16x9">
    <iframe class="embed-responsive-item" src="https://bst-ekspres.com/tax/extern.php"></iframe>
  </div>
  <!--<div class="row">
    <div class="col-md-6">
      <div class="p-5 border">
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Necessitatibus veniam ipsa earum quibusdam, atque ipsum error maiores
          natus iusto fugit id saepe neque rerum magni laudantium accusantium
          dolorem numquam quasi.
        </p>
      </div>
    </div>
    <div class="col-md-6">
      <div class="p-5 border">
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Necessitatibus veniam ipsa earum quibusdam, atque ipsum error maiores
          natus iusto fugit id saepe neque rerum magni laudantium accusantium
          dolorem numquam quasi.
        </p>
      </div>
    </div>
  </div>-->
</div>