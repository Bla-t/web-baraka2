<?php
require_once "method.php";
$mhs = new Mahasiswa();
$request_method = $_SERVER["REQUEST_METHOD"];
switch ($request_method) {
	case 'GET':
		if (!empty($_GET["dari"])) {
			$dari = $_GET["dari"];
			$tujuan = $_GET["tujuan"];
			$mhs->get_mhs($dari, $tujuan);
		} else {
			$mhs->get_mhss();
		}
		break;
	case 'POST':
		$mhs->insert_mhs();
		break;
	case 'PUT':
		if (!empty($_POST["id"])) {
			$id = intval($_POST["id"]);
			$mhs->update_mhs($id);
		} else {
			header("HTTP/1.0 405 Method Not Allowed");
		}
		break;
	case 'DELETE':
		$id = intval($_GET["id"]);
		$mhs->delete_mhs($id);
		break;
	default:
		// Invalid Request Method
		header("HTTP/1.0 405 Method Not Allowed");
		break;
}
