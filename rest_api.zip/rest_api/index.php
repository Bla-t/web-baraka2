<?php
// error_reporting(0);
// ini_set('display_errors', 0);
// 
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>testing -api</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</head>

<body>
  <div class="section">
    <form action="" method="GET">
      <div class="row justify-content-center mt-5">
        <div class="col-md-3">
          <div class="form-group-row">
            <label for="input1"> dari:</label>
            <select name="dari" id="input1" class="form-control">
              <option value="SPRT">blok b</option>
              <option value="JTM2">blitar</option>
              <option value="JTG1">semarang</option>
              <option value="SBY">surabaya</option>
              <option value="BLI">denpasar</option>
            </select>
          </div>
          <div class="form-group-row">
            <label for="input2"> tujuan:</label>
            <select name="tujuan" id="input2" class="form-control">
              <option value="JAKARTA">jakarta</option>
              <option value="SEMARANG">semarang</option>
              <option value="BALI">denpasar</option>
              <option value="PASURUHAN">pasuruan</option>
              <option value="TEGAL">tegal</option>
            </select>
          </div>
          <div class="form-group-row">
            <label for="p1"> kilogram:</label>
            <input id="p1" name="berat" type="text" class="form-control">
          </div>
          <div class="form-group-row mt-3">
            <button class="btn btn-warning" type="submit">cek</button>
          </div>
        </div>
      </div>
      <div class="row justify-content-center">
        <div class="col-md-3">
          <h3 class="display-5 text-center" id="hasil">
            <?php
            ini_set('allow_url_fopen', 1);
            $dari = $_GET['dari'];
            $tujuan = $_GET['tujuan'];
            $berat = $_GET['berat'];
            $url = 'http://localhost/web-baraka2/rest_api/mahasiswa/?dari=' . $dari . '&tujuan=' . $tujuan;
            // var_dump($url);
            // exit;
            $isi = json_decode(file_get_contents($url), true);
            // var_dump($isi['data']);
            $isi = $isi['data'][0];
            // $berat = 1;
            function rupiah($angka)
            {

              $bulat = substr($angka, -3);
              if ($bulat < 500) {
                $akhir = $angka - $bulat;
              } else {
                $akhir = $angka + (1000 - $bulat);
              }

              $hasil_rupiah = "Rp. " . number_format($akhir, 2, ',', '.');
              return $hasil_rupiah;
            }
            if ($berat > 0 && $berat < 3) {
              echo rupiah(($berat - $isi['KONS1-2']) * $isi['KG1-2'] + $isi['MIN1-2']);
            }
            ?>
          </h3>
        </div>
      </div>
    </form>
  </div>
  <footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
  </footer>
</body>

</html>