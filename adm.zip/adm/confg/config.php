<?php
// define('baseurl', 'http://localhost/web-baraka2/adm');

$conn = mysqli_connect('localhost', 'root', '', 'tes');

if (!$conn) {
  die($conn);
}
